<?php

namespace Database\Seeders;

use App\Models\Part;
use App\Models\PartItem;
use App\Models\PartItemStatus;
use App\Models\StorageLocation;
use Illuminate\Database\Seeder;

class PartItemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $status = PartItemStatus::query()
            ->where('name', 'В наличии')->first();
        $location = StorageLocation::query()
            ->where('name', 'Главный склад')->first();

        $enginePart = Part::query()
            ->where('name', 'Двигатель ВАЗ-2106')->first();
        $filterPart = Part::query()
            ->where('name', 'Фильтр масла Mann')->first();

        PartItem::query()
            ->updateOrCreate([
                'serial_number' => 'ENG-001',
                'part_id' => $enginePart->id,
                'status_id' => $status->id,
                'storage_location_id' => $location->id,
            ]);

        PartItem::query()
            ->updateOrCreate([
                'serial_number' => 'FLT-002',
                'part_id' => $filterPart->id,
                'status_id' => $status->id,
                'storage_location_id' => $location->id,
            ]);
    }
}
