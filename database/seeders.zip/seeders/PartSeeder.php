<?php

namespace Database\Seeders;

use App\Models\Part;
use App\Models\PartTemplate;
use App\Models\RotationMethod;
use Illuminate\Database\Seeder;

class PartSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $template = PartTemplate::query()
            ->where('name', 'Двигатель')->first();
        $rotation = RotationMethod::query()
            ->firstOrCreate(['name' => 'FIFO']);

        Part::query()
            ->updateOrCreate([
                'name' => 'Двигатель ВАЗ-2106',
                'template_id' => $template->id,
                'rotation_method_id' => $rotation->id,
                'minimum_stock' => 2,
            ]);

        Part::query()
            ->updateOrCreate([
                'name' => 'Фильтр масла Mann',
                'template_id' => PartTemplate::query()
                    ->where('name', 'Фильтр масла')->first()->id,
                'rotation_method_id' => $rotation->id,
                'minimum_stock' => 5,
            ]);
    }
}
